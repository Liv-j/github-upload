let order = [];//order of sequence
let playerOrder = [];//order of the player
let flash;//# of flash
let turn;//round
let good;//if the player is right or wrong
let compTurn;//computers turn or player
let intervalId;//to clear interval
let strict = false;//if player makes one mistake= game over
let noise = true;//sound
let on = false;//if program active or not 

//conneting html elments with js
const turnCounter = document.querySelector("#turn");
const topLeft = document.querySelector("#topleft");
const topRight = document.querySelector("#topright");
const bottomLeft = document.querySelector("#bottomleft");
const bottomRight = document.querySelector("#bottomright");
const startButton = document.querySelector("#start");

//when the start button is clicked it turns on and start the game
startButton.addEventListener('click', (event) => {
        on = true;
        strict = true;
        play();
});

//function that triggers all events in the game
function play() {
  //these variables is to "reset" the game
  order = [];
  playerOrder = [];
  flash = 0;
  intervalId = 0;
  turn = 1;
  turnCounter.innerHTML = counts;
  good = true;
  //for the sequence of flashes
  for (var i = 0; i < 100; i++) {
    order.push(Math.floor(Math.random() * 4) + 1);
  }
  //fisrt turn is the computer's
  compTurn = true;
  //runs gameTurn function every 800
  intervalId = setInterval(gameTurn, 800);
}

//function for the computer's turn
function gameTurn() {
  //so player can't click any button
  on = false;
  //to finnish computers turn
  if (flash == turn) {
    clearInterval(intervalId);
    compTurn = false;
    clearColor();
    on = true;
  }

  //computer's turn
  if (compTurn) {
    clearColor();
    //to flash the button
    setTimeout(() => {
      if (order[flash] == 1) one();
      if (order[flash] == 2) two();
      if (order[flash] == 3) three();
      if (order[flash] == 4) four();
      flash++;
    }, 200);
  }
}

//what happens if (one()) top left button is in the sequence
function one() {
  //for audio 
  if (noise) {
    let audio = document.getElementById("clip1");
    audio.play();
  }
  //for the flash
  noise = true;
  topLeft.style.backgroundColor = "#EB8CB1";
}

//what happens if (two()) top right button is in the sequence
function two() {
  //for audio
  if (noise) {
    let audio = document.getElementById("clip2");
    audio.play();
  }
  //for the flash
  noise = true;
  topRight.style.backgroundColor = "#646BBD";
}

//what happens if (three()) bottom left button is in the sequence
function three() {
  //for audio
  if (noise) {
    let audio = document.getElementById("clip3");
    audio.play();
  }
  //for the flash
  noise = true;
  bottomLeft.style.backgroundColor = "#80C2C0";
}

//what happens if (four()) bottom right button is in the sequence
function four() {
  //for audio
  if (noise) {
    let audio = document.getElementById("clip4");
    audio.play();
  }
  //for the flash
  noise = true;
  bottomRight.style.backgroundColor = "#B269B3";
}

//function to make the button go back to the original color
function clearColor() {
  topLeft.style.backgroundColor = "#F0457A";
  topRight.style.backgroundColor = "#331EBD";
  bottomLeft.style.backgroundColor = "#179EC2";
  bottomRight.style.backgroundColor = "#9F25B3";
}

//function to flash all the color at the same time
function flashColor() {
  topLeft.style.backgroundColor = "#EB8CB1";
  topRight.style.backgroundColor = "#646BBD";
  bottomLeft.style.backgroundColor = "#80C2C0";
  bottomRight.style.backgroundColor = "#B269B3";
}

//events if the player push the top left button 
topLeft.addEventListener('click', (event) => {
  if (on) {
    playerOrder.push(1);
    check();
    one();
      setTimeout(() => {
        clearColor();
      }, 300);
    }
})

//events if the player push the top right button 
topRight.addEventListener('click', (event) => {
  if (on) {
    playerOrder.push(2);
    check();
    two();
    setTimeout(() => {
    clearColor();
    }, 300);
    }
})

//events if the player push the bottom left button 
bottomLeft.addEventListener('click', (event) => {
  if (on) {
    playerOrder.push(3);
    check();
    three();
    setTimeout(() => {
    clearColor();
    }, 300);
    }
})

//events if the player push the bottom right button 
bottomRight.addEventListener('click', (event) => {
  if (on) {
    playerOrder.push(4);
    check();
    four();
    setTimeout(() => {
    clearColor();
    }, 300);
    }
})

//checks if the player is correct 
function check() {
  //if incorrect
  if (playerOrder[playerOrder.length - 1] !== order[playerOrder.length - 1])
    good = false;

  //what happens if player is incorrect
  if (good == false) {
    flashColor();
    //message to say that it's "game over"
    turnCounter.innerHTML = "Game Over!<BR>Game will reset in a moment.";
    setTimeout(() => {
      //set back to the number of counts
      turnCounter.innerHTML = counts;
      clearColor();

      //to "reset" the game 
      if (strict) {
        play(); 
      }
    }, 5000);//time before reset
    
    //to not make a noise 
    noise = false;
  }

  //if player is correct
  if (turn == playerOrder.length && good) {
    turn++;
    counts++;
    playerOrder = [];
    compTurn = true;
    flash = 0;
    turnCounter.innerHTML = counts;
    intervalId = setInterval(gameTurn, 800);
    //save counts to user's account
    let showcounts= counts.toString ();
    localStorage.setItem(username, showcounts);
    
  }

}
