
     //sidebar js
      //Flowchart Log_out function start
        function Log_out() {
            //saves info to account
            let showcounts= counts.toString ();
            localStorage.setItem(username, showcounts);
            
            //to show login page if the user wants to go back to main 
            localStorage.setItem("active", "0");
            //to go to log out page
            location.href ="logout.html"
        }
        //Flowchart Log_out function stop

     //sidebar js start   
        function openNav() {
            document.getElementById("sidebar").style.width = "250px";
            //to get information of the active account
            document.getElementById("usernamedisplay").innerHTML = username.toUpperCase() 
            //flowchart retrieve funtion part 2 start
            document.getElementById("countdisplay").innerHTML = counts + " rounds"
            document.getElementById("soupdisplay").innerHTML = soups + " soups"
            //flowchart retrieve funtion part 2 end    
        }
        
        function closeNav() {
            document.getElementById("sidebar").style.width = "0";
        }
  
     //sidebar js end
    
    //Flowchart Log_in function start
    function Log_in() {
    
    userList = ['bob','steve','kevin'];//list of users
    passList=['123','456','789'];//list of passwords
     counts = 0;
     soups =  0;
    
     active="0";//to know wich page is active(login or main)
     loginusername="";
     username = document.getElementById("username").value.toLowerCase();
     password = document.getElementById("password").value;
    let newMessage;
    let i= userList.indexOf(username);
    if ( i!== -1 && passList.indexOf(password) !== -1 )  {
        loginpage.style.display = "none";
        gamepage.style.display = "block";
        //flowchart retrieve funtion part 1 start
        // retrieve username + counts + soups 
        counts = localStorage.getItem(username);
        soups = Math.floor(Number(counts)/10);
        localStorage.setItem("active", "1");
        localStorage.setItem("loginusername", username);
        //flowchart retrieve funtion part 1 end
        
    } else {
        //message if the username or password is invalid
        newMessage = "Username or password invalid.<BR>" + "Please try again.";
    }
    document.getElementById("Message").innerHTML = newMessage;
    }
    //Flowchart Log_in function stop
   