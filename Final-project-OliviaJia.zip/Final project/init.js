let userList = ['bob','steve','kevin'];
let passList=['123','456','789'];
let counts = 0;
let soups =  0;
let username ="";
let active="0";
let loginusername="";
/*function to assure that the user is logged in (if they go to about page)
and keeps the count for the # of rounds and soup*/
function init() {

    active = localStorage.getItem("active");
    if  (active == "1") {
        username = localStorage.getItem("loginusername");
        counts = localStorage.getItem(username);
        soups = Math.floor(Number(counts)/10);
        loginpage.style.display = "none";
        gamepage.style.display = "block";
    }

}
